import React, { useRef } from "react";

export default function AddOrder() {
  var x1 = useRef();
  var x2 = useRef();
  var x3 = useRef();
  var x4 = useRef();
  function f1() {
    var data = {
      orderId: x1.current.value,
      deliveryDate: x2.current.value,
      deliveryAddress: x3.current.value,
      deliveryfee: x4.current.value,
    };
    data = JSON.stringify(data);
    console.log(data);

    fetch("http://localhost:3000/addOrder", {
      method: "POST",
      body: data,
      headers: { "content-type": "application/json" },
    })
      .then((val) => {
        console.log(val);
        alert("Data Submited Successfully !");
      })
      .catch((err) => {
        console.log(err);
      });
  }
  return (
    <div>
      <input type="number" placeholder="Enter order id" ref={x1} /> <br />
      <input type="date" placeholder="Enter Delivery Date" ref={x2} /> <br />
      <input type="text" placeholder="Enter Delivery address" ref={x3} /> <br />
      <input type="number" placeholder="Enter Fee" ref={x4} /> <br />
      <button onClick={f1}>Submit</button>
    </div>
    
  );
}
