import React, { useEffect, useState ,useRef} from "react";

export default function Orders() {
  const [data, setOrder] = useState([]);
  var x1 = useRef();
  useEffect(() => {
    fetch("http://localhost:3000/getorders")
      .then((res) => res.json())
      .then((val) => {
        setOrder(val);
        console.log(val);
      })
      .catch((err) => console.error("Unable to fetch", err));
  });
    return (
        
    
    <table class="table">
      <thead>
        <tr>
          <th scope="col">orderId</th>
          <th scope="col">deliveryDate</th>
          <th scope="col">deliveyAddress</th>
          <th scope="col">deliveryfee</th>
        </tr>
      </thead>
      <tbody>
        {data &&
          data.length > 0 &&
          data.map((value) => {
            return (       
                <tr>
                  <td>{value.orderId}</td>
                  <td>{value.orderDate}</td>
                  <td>{value.deliveryAddress}</td>
                  <td>{value.deliveryfee}</td>
                </tr>
              
            );
          })}
      </tbody>
    </table>
  );
}
