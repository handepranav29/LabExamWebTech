import React from "react";
import { createBrowserRouter } from "react-router-dom";
import Orders from "./components/Orders";
import App from "./components/App";
import AddOrder from "./components/AddOrder";
import DeleteOrder from "./components/DeleteOrder";


const projectroute = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      {
        path: "orders",
        element: <Orders />,
      },
      {
        path: "addOrder",
        element: <AddOrder />,
      },
      
      {
        path: "delete",
        element: <DeleteOrder />,
      },
    ],
  },
]);

export default projectroute;
