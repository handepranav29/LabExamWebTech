C:\Program Files\MongoDB\Server\4.2\bin

npm i express mongoose cors

var deliverySchema = new Schema({
  orderId: Number,
  deliveryDate: Date,
  deliveryAddress: String,
  deliveryfee: Number,
});

db.orders.insert({orderId: 1, deliveryDate: 23-11-2024, deliveryAddress:'Nanded',deliveryfee:1000})

db.orders.insert({orderId: 2, deliveryDate: 26-11-2024, deliveryAddress:'Nashik',deliveryfee:500})
db.orders.insert({orderId: 3, deliveryDate: 2-12-2024, deliveryAddress:'Pune',deliveryfee:1200})
db.orders.insert({orderId: 4, deliveryDate: 2-1-2025, deliveryAddress:'Indore',deliveryfee:1500})
db.orders.insert({orderId: 5, deliveryDate: 23-11-2024, deliveryAddress:'Nanded',deliveryfee:1000})
db.orders.insert({orderId: 6, deliveryDate: 24-11-2024, deliveryAddress:'Nanded',deliveryfee:1000})
